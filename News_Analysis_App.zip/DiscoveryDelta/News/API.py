# API Authentication Credentials
alyien = {'api_id': '79479bf5', 'api_key': '493cc9135d9f8cfc8b07187aedfdd391', 'text_api_id': '4fe258ca',
          'text_api_key': 'd8dec008da6e0ec251a6609d04b1e3f0',
          'api': 'https://api.newsapi.aylien.com/api/v1/'}

headers = {'X-AYLIEN-NewsAPI-Application-ID': alyien['api_id'], 'X-AYLIEN-NewsAPI-Application-Key': alyien['api_key']}

news_config = ['X-AYLIEN-NewsAPI-Application-ID', 'X-AYLIEN-NewsAPI-Application-Key']

endpoints = {'stories': alyien['api']+'stories?','time_series': alyien['api']+'time_series?', 'trends': alyien['api']+'trends?', 'histograms': 'histograms?'}


