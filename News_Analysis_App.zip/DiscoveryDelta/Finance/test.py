from News import API
import aylien_news_api
from aylien_news_api.rest import ApiException
import time
import json
import pickle

if __name__ == '__main__':

    # configure application
    # app ID
    aylien_news_api.configuration.api_key[API.news_config[0]] = API.headers['X-AYLIEN-NewsAPI-Application-ID']
    # app Key
    aylien_news_api.configuration.api_key[API.news_config[1]] = API.headers['X-AYLIEN-NewsAPI-Application-Key']
    # init app instance
    news_api = aylien_news_api.DefaultApi()


    # testing IPTC Codes
    # 0400000 Economy, business and finance
    financial_opts = {
        'categories_taxonomy': 'iptc-subjectcode',
        'categories_id': ['04000000'],
        'language': ['en'],
        'published_at_start': 'NOW-1DAYS',
        'published_at_end': 'NOW',
        'source_locations_country': ['GB'],
        'source_rankings_alexa_rank_min': 1,
        'source_rankings_alexa_rank_max': 120,
        'cursor': '*',
        'per_page': 15
    }

    fin_opts = {
        'categories_taxonomy': 'iab-qag',
        'categories_id': ['IAB13'],
        'language': ['en'],
        'published_at_start': 'NOW-14DAYS',
        'published_at_end': 'NOW',
        'source_locations_country': ['GB'],
        'source_rankings_alexa_rank_min': 1,
        'source_rankings_alexa_rank_max': 120,
        'cursor': '*',
        'per_page': 15
    }


    def fetch_stories(params, count=100):

        fetched_stories = []
        stories = None

        while stories is None or len(stories) > 0:
            try:
                r = news_api.list_stories(**params)
            except ApiException as e:
                if e.status == 429:
                    print(e)
                    print('limit exceeded.. waiting 60 seconds')
                    time.sleep(60)
                    continue

            stories = r.stories
            params['cursor'] = r.next_page_cursor

            fetched_stories += (stories)
            print('Fetched {} stories. Total count so far {}'.format(len(stories), len(fetched_stories)))
            if len(stories) == 0 or stories is None:
                return fetched_stories

            elif len(fetched_stories) >= count:
                return fetched_stories

    fin_stories = fetch_stories(params=fin_opts, count=200)

    print(len(fin_stories))
    for story in fin_stories:
        print(story.title)
        print(story.summary.sentences)
        print(story.source.name)
        print(story.links.permalink)
        print(story.published_at)
        print(story.keywords)
        print(story.sentiment.body.polarity)
        print()

    # write json to file for post processing
    # use fin_opts IAB13 for more reliable financial news
    with open('financial_news.txt', 'wb') as news_file:
        pickle.dump(fin_stories, news_file)








