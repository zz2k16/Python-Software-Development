import pickle
import pandas as pd
import openpyxl
pd.set_option('display.max_columns', 15)
pd.set_option('display.width', 1200)

with open('financial_news.txt', 'rb') as f:
    news = pickle.load(f)
    f.close()

# print(len(news))
# print(type(news))
# print(type(news[0]))
#
# news_dict = news[0].to_dict()
# #print(news_dict)
#
# for k in news_dict:
#     print(k)
#     print(news_dict[k])
#     print()
#
# columns = ['title', 'summary.sentences', 'source.name', 'keywords', 'sentiment.body.polarity', 'published_at', 'links.permalink']
#
#
# stories = []
# for story in news:
#     tmp = []
#     print(story.title)
#     tmp.append(story.title)
#
#     print(''.join(story.summary.sentences))
#     tmp.append(''.join(story.summary.sentences))
#
#     print(story.source.name)
#     tmp.append(story.source.name)
#
#     print(' '.join(story.keywords))
#     tmp.append(' '.join(story.keywords))
#
#     print(story.sentiment.body.polarity)
#     tmp.append(story.sentiment.body.polarity)
#
#     print(story.published_at)
#     tmp.append(story.published_at)
#     print()
#     stories.append(tmp)


def extract_stories(src):
    news_list = []
    for story in src:
        tmp = []
        tmp.append(story.title)
        tmp.append(''.join(story.summary.sentences))
        tmp.append(story.source.name)
        tmp.append(' '.join(story.keywords))
        tmp.append(story.sentiment.body.polarity)
        tmp.append(story.published_at)
        tmp.append(story.links.permalink)
        news_list.append(tmp)
    return news_list


stories = extract_stories(news)


# convert stories into dataframe
def story_to_df(stories):
    columns = ['Title', 'Summary', 'Source Name', 'Word', 'Description', 'Date Published', 'URL']
    df = pd.DataFrame(stories, columns=columns)

    df = df.replace(r'\n', ' ', regex=True)
    df = df.replace(r'\n\n', ' ', regex=True)
    df = df.replace(r'Image copyright', ' ', regex=True)
    df = df.replace(r'Image caption', ' ', regex=True)

    # add column values
    df['Data Type'] = 'Unstructured'
    df['Source_1'] = 'External'
    df['Source_2'] = 'News'
    df['Source_3'] = 'Financial'
    df['Type'] = 'News Article'
    return df


df = story_to_df(stories)

# verify df structure and contents

print(df.head())
print(df['Summary'][0])

# write to excel file
df.to_excel('News.xlsx', encoding='utf8')

#TODO extract news into Pandas DF and match columns to excel file
