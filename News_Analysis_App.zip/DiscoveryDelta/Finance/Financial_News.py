from Finance.Aylien import Aylien
from aylien_news_api.rest import ApiException
import time

class Financial(Aylien):
    def __init__(self):
        Aylien.__init__(self)

    def news(self, days=7):
        financial_opts = {
            'categories_taxonomy': 'iptc-subjectcode',
            'categories_id': ['04000000'],
            'language': ['en'],
            'published_at_start': 'NOW-' + str(days) + 'DAYS/DAY',
            'published_at_end': 'NOW',
            'source_locations_country': ['GB'],
            'source_rankings_alexa_rank_min': 1,
            'source_rankings_alexa_rank_max': 100
        }
        try:
            r = self.api.list_stories(**financial_opts)
            return r.stories
        except ApiException as e:
            print(e)



if __name__ == '__main__':
    fin = Financial()
    results = fin.news(days=7)
    print(len(results))
    print(results)


