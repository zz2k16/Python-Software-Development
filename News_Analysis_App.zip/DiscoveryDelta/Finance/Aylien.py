from News import API
import aylien_news_api


class Aylien:
    def __init__(self):
        # configure application
        # app ID
        aylien_news_api.configuration.api_key[API.news_config[0]] = API.headers['X-AYLIEN-NewsAPI-Application-ID']
        # app Key
        aylien_news_api.configuration.api_key[API.news_config[1]] = API.headers['X-AYLIEN-NewsAPI-Application-Key']
        self.api = aylien_news_api.DefaultApi()


    