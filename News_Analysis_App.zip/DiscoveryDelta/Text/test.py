from Text import API
from aylienapiclient import textapi

client = textapi.Client(API.alyien['api_id'], API.alyien['api_key'])

sent_dict = {'text': 'John is a very good employee'}

sentiment = client.Sentiment(sent_dict)
print(sentiment)

url = 'https://www.theguardian.com/business/2018/jun/28/fca-investigates-allegations-of-insider-trading-at-carillion'

summary = client.Summarize({'url': url, 'sentences_number': 5})

for sentences in summary['sentences']:
    print(sentences)

sents = client.Sentiment({'text': summary['sentences']})
ents = client.Entities({'text': summary['sentences']})

print(summary.keys())
print(sents.keys())
print(ents.keys())

print('entities keys: ', ents['entities'].keys())

print(sents['polarity'], sents['subjectivity'])
for entity in ents['entities']:
    print(ents['entities'][entity])

# Article Extraction
article = client.Extract({'url':url})
print(article.keys())
#print(article['article'])

article_summary = client.Summarize({'title':article['title'], 'text': article['article'], 'sentences_number': 5})
print(article_summary.keys())
for sent in article_summary['sentences']:
    print(sent)



# combined calls
# combined = client.Combined({'url': url, 'endpoint': ['sentiment', 'entities', 'summarize']})
# print(combined.keys())
# print(combined['results'])