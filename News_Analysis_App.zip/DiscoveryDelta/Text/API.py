# API Authentication Credentials
alyien = {'api_id': '4fe258ca',
          'api_key': 'd8dec008da6e0ec251a6609d04b1e3f0',
          'api': 'https://api.aylien.com/api/v1'}

headers = {'X-AYLIEN-TextAPI-Application-ID': alyien['api_id'], 'X-AYLIEN-TextAPI-Application-Key': alyien['api_key']}

# endpoints = {'stories': alyien['api']+'stories?','time_series': alyien['api']+'time_series?', 'trends': alyien['api']+'trends?', 'histograms': 'histograms?'}


